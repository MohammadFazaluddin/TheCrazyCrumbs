import { FloatingNav } from './components/FloatingNav';
import { CommissionCounter } from './components/CommissionCounter';
import { Hero } from './components/Hero';
import { SignatureCollection } from './components/SignatureCollection';
import { LawOfFour } from './components/LawOfFour';
import { CommissionForm } from './components/CommissionForm';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="size-full overflow-x-hidden">
      <FloatingNav />
      <CommissionCounter />

      <main>
        <Hero />
        <SignatureCollection />
        <LawOfFour />
        <CommissionForm />
      </main>

      <Footer />
    </div>
  );
}