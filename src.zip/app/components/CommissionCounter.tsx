import { motion } from 'motion/react';

export function CommissionCounter() {
  const today = new Date();
  const dateString = today.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5, duration: 1 }}
      className="fixed top-24 right-8 z-40 text-right"
      style={{ fontFamily: 'var(--font-sans)' }}
    >
      <div className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60 mb-1">
        Available Commissions
      </div>
      <div className="text-sm text-[var(--charcoal)]">
        {dateString}
      </div>
      <div className="mt-2" style={{ fontFamily: 'var(--font-serif)' }}>
        <span className="text-3xl text-[var(--bespoke-gold)]">2</span>
        <span className="text-xl text-[var(--charcoal)] opacity-40">/4</span>
      </div>
    </motion.div>
  );
}
