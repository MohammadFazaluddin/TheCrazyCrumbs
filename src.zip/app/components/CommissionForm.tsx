import { motion } from 'motion/react';
import { useInView } from './hooks/useInView';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function CommissionForm() {
  const [ref, isInView] = useInView({ threshold: 0.2, triggerOnce: true });

  return (
    <section id="commission" className="py-32 px-8 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full opacity-5">
        <div className="absolute inset-0 bg-gradient-to-l from-[var(--crazy-pink)] to-transparent" />
      </div>

      <div className="max-w-[1400px] mx-auto relative z-10">
        <div className="grid grid-cols-12 gap-16 items-start">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="col-span-5"
          >
            <div className="sticky top-32">
              <div className="text-xs tracking-[0.3em] uppercase text-[var(--charcoal)] opacity-60 mb-4">
                Commission Your Masterpiece
              </div>

              <h2
                style={{ fontFamily: 'var(--font-serif)' }}
                className="text-5xl text-[var(--charcoal)] mb-6 leading-tight"
              >
                Request a<br />
                <span className="italic text-[var(--crazy-pink)]">Commission</span>
              </h2>

              <div className="w-20 h-[1px] bg-[var(--bespoke-gold)] mb-8" />

              <p
                style={{ fontFamily: 'var(--font-sans)' }}
                className="text-base leading-relaxed text-[var(--charcoal)] opacity-70 mb-8"
              >
                Share your vision. Our Master Chef will respond within 24 hours with availability
                and a bespoke proposal for your commissioned creation.
              </p>

              <div className="relative aspect-[3/4] overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e?w=600&h=800&fit=crop"
                  alt="Master Chef at work"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
                  <p
                    style={{ fontFamily: 'var(--font-serif)' }}
                    className="text-white text-sm italic"
                  >
                    Every commission begins with a conversation about your vision.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="col-span-7"
          >
            <form className="space-y-8" style={{ fontFamily: 'var(--font-sans)' }}>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                    Full Name
                  </label>
                  <input
                    type="text"
                    className="w-full border-b border-[var(--charcoal)]/20 py-3 bg-transparent focus:border-[var(--bespoke-gold)] focus:outline-none transition-colors"
                    placeholder="Jane Doe"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                    Email Address
                  </label>
                  <input
                    type="email"
                    className="w-full border-b border-[var(--charcoal)]/20 py-3 bg-transparent focus:border-[var(--bespoke-gold)] focus:outline-none transition-colors"
                    placeholder="jane@example.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                  Desired Creation
                </label>
                <select
                  className="w-full border-b border-[var(--charcoal)]/20 py-3 bg-transparent focus:border-[var(--bespoke-gold)] focus:outline-none transition-colors"
                >
                  <option value="">Select a creation type</option>
                  <option value="tres-leches">World-Class Tres Leches</option>
                  <option value="ice-cream">Artisanal Ice Cream</option>
                  <option value="pastry">Heritage Pastry</option>
                  <option value="custom">Custom Creation</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                  Preferred Date
                </label>
                <input
                  type="date"
                  className="w-full border-b border-[var(--charcoal)]/20 py-3 bg-transparent focus:border-[var(--bespoke-gold)] focus:outline-none transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                  Your Vision
                </label>
                <textarea
                  rows={6}
                  className="w-full border border-[var(--charcoal)]/20 p-4 bg-transparent focus:border-[var(--bespoke-gold)] focus:outline-none transition-colors resize-none"
                  placeholder="Describe your vision, flavor preferences, dietary requirements, and the occasion..."
                />
              </div>

              <div className="pt-6">
                <button
                  type="submit"
                  className="w-full py-4 bg-[var(--bespoke-gold)] text-white hover:bg-[var(--charcoal)] transition-all duration-500 tracking-widest text-xs uppercase"
                >
                  Submit Commission Request
                </button>
              </div>

              <p className="text-xs text-center text-[var(--charcoal)] opacity-50 italic">
                Pricing is fixed based on creation type. No negotiations. No haggling.
              </p>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
