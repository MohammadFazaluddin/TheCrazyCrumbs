import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

export function FloatingNav() {
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }

      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  return (
    <motion.nav
      initial={{ y: 0, opacity: 1 }}
      animate={{
        y: isVisible ? 0 : -100,
        opacity: isVisible ? 1 : 0
      }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="fixed top-0 left-0 right-0 z-50 px-8 py-6"
      style={{
        background: 'rgba(250, 250, 250, 0.85)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(42, 42, 42, 0.05)'
      }}
    >
      <div className="max-w-[1600px] mx-auto flex items-center justify-between">
        <div style={{ fontFamily: 'var(--font-serif)' }} className="tracking-wide">
          <span className="text-[2rem] text-[var(--charcoal)]">Crazy Crumbs</span>
        </div>

        <div className="flex items-center gap-12" style={{ fontFamily: 'var(--font-sans)' }}>
          <a href="#collection" className="text-[var(--charcoal)] hover:text-[var(--crazy-pink)] transition-colors duration-300 tracking-wide text-sm uppercase">
            The Collection
          </a>
          <a href="#commission" className="text-[var(--charcoal)] hover:text-[var(--crazy-pink)] transition-colors duration-300 tracking-wide text-sm uppercase">
            Commission
          </a>
          <a href="#philosophy" className="text-[var(--charcoal)] hover:text-[var(--crazy-pink)] transition-colors duration-300 tracking-wide text-sm uppercase">
            Philosophy
          </a>

          <button
            className="px-6 py-2 border border-[var(--bespoke-gold)] text-[var(--charcoal)] hover:bg-[var(--bespoke-gold)] hover:text-white transition-all duration-300 tracking-wide text-sm uppercase"
            style={{ borderWidth: '1px' }}
          >
            Request a Commission
          </button>
        </div>
      </div>
    </motion.nav>
  );
}
