export function Footer() {
  return (
    <footer className="py-16 px-8 bg-[var(--charcoal)] text-white">
      <div className="max-w-[1600px] mx-auto">
        <div className="grid grid-cols-12 gap-12 mb-12">
          <div className="col-span-4">
            <h3
              style={{ fontFamily: 'var(--font-serif)' }}
              className="text-2xl mb-4"
            >
              Crazy Crumbs
            </h3>
            <p
              style={{ fontFamily: 'var(--font-sans)' }}
              className="text-sm leading-relaxed opacity-70"
            >
              A digital flagship for artisanal confections. Four commissions daily.
              Zero preservatives. Uncompromising quality.
            </p>
          </div>

          <div className="col-span-2">
            <h4
              style={{ fontFamily: 'var(--font-sans)' }}
              className="text-xs tracking-widest uppercase mb-4 opacity-60"
            >
              Explore
            </h4>
            <ul className="space-y-2 text-sm" style={{ fontFamily: 'var(--font-sans)' }}>
              <li><a href="#collection" className="hover:text-[var(--bespoke-gold)] transition-colors">The Collection</a></li>
              <li><a href="#philosophy" className="hover:text-[var(--bespoke-gold)] transition-colors">Philosophy</a></li>
              <li><a href="#commission" className="hover:text-[var(--bespoke-gold)] transition-colors">Commission</a></li>
            </ul>
          </div>

          <div className="col-span-3">
            <h4
              style={{ fontFamily: 'var(--font-sans)' }}
              className="text-xs tracking-widest uppercase mb-4 opacity-60"
            >
              Contact
            </h4>
            <ul className="space-y-2 text-sm" style={{ fontFamily: 'var(--font-sans)' }}>
              <li className="opacity-70">commissions@crazycrumbs.com</li>
              <li className="opacity-70">Available: Tue - Sat, 9AM - 5PM</li>
            </ul>
          </div>

          <div className="col-span-3">
            <h4
              style={{ fontFamily: 'var(--font-sans)' }}
              className="text-xs tracking-widest uppercase mb-4 opacity-60"
            >
              The Promise
            </h4>
            <ul className="space-y-2 text-sm" style={{ fontFamily: 'var(--font-sans)' }}>
              <li className="flex items-start gap-2">
                <span className="text-[var(--bespoke-gold)]">✓</span>
                <span className="opacity-70">Made from scratch daily</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[var(--bespoke-gold)]">✓</span>
                <span className="opacity-70">Zero preservatives or stabilizers</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[var(--bespoke-gold)]">✓</span>
                <span className="opacity-70">Fixed, transparent pricing</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10">
          <div className="flex items-center justify-between">
            <p
              style={{ fontFamily: 'var(--font-sans)' }}
              className="text-xs opacity-50"
            >
              © 2026 Crazy Crumbs. All rights reserved.
            </p>
            <p
              style={{ fontFamily: 'var(--font-sans)' }}
              className="text-xs opacity-50"
            >
              A <span className="text-[var(--bespoke-gold)]">Moon Enterprises</span> Digital Flagship
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
