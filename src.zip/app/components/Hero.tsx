import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0 bg-[var(--gallery-white)]" />

      <div className="relative max-w-[1600px] mx-auto w-full px-8 pt-32 pb-20">
        <div className="grid grid-cols-12 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="col-span-6 z-10"
          >
            <div className="space-y-6">
              <div className="text-xs tracking-[0.3em] uppercase text-[var(--charcoal)] opacity-60">
                Modern Heritage
              </div>

              <h1
                style={{ fontFamily: 'var(--font-serif)' }}
                className="text-[5rem] leading-[1.1] text-[var(--charcoal)]"
              >
                The Art of<br />
                <span className="italic text-[var(--crazy-pink)]">Bespoke</span><br />
                Confection
              </h1>

              <div className="w-20 h-[1px] bg-[var(--bespoke-gold)]" />

              <p
                style={{ fontFamily: 'var(--font-sans)' }}
                className="text-lg leading-relaxed text-[var(--charcoal)] opacity-80 max-w-md"
              >
                Four masterpieces daily. Zero preservatives. Each creation handcrafted by our Master Chef,
                delivered through an unboxing experience that honors the craft.
              </p>

              <div className="pt-4">
                <button
                  className="px-8 py-4 border-2 border-[var(--bespoke-gold)] text-[var(--charcoal)] hover:bg-[var(--bespoke-gold)] hover:text-white transition-all duration-500 tracking-widest text-xs uppercase"
                >
                  Explore The Collection
                </button>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.2, delay: 0.2, ease: 'easeOut' }}
            className="col-span-6 relative"
          >
            <div className="relative aspect-[3/4] overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[var(--crazy-pink)] to-[var(--bespoke-gold)] opacity-10" />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&h=1200&fit=crop"
                alt="Artisanal cake detail"
                className="w-full h-full object-cover"
              />
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="absolute -bottom-8 -left-12 bg-white p-8 shadow-2xl max-w-xs z-20"
            >
              <p style={{ fontFamily: 'var(--font-serif)' }} className="text-sm italic text-[var(--charcoal)] leading-relaxed">
                "The silkiness of our signature tres leches comes from a 48-hour cold soak—patience
                rewarded with perfection."
              </p>
              <div className="mt-3 text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                — Master Chef
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
