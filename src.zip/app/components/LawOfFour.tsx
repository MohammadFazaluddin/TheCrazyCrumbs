import { motion } from 'motion/react';
import { useInView } from './hooks/useInView';

export function LawOfFour() {
  const [ref, isInView] = useInView({ threshold: 0.3, triggerOnce: true });

  return (
    <section id="philosophy" className="py-32 px-8 bg-[var(--gallery-white)]">
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-12 gap-12 items-center">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1 }}
            className="col-span-5"
          >
            <div className="relative">
              <div className="absolute -top-8 -left-8 text-[12rem] opacity-5" style={{ fontFamily: 'var(--font-serif)' }}>
                4
              </div>
              <div className="relative z-10">
                <h2
                  style={{ fontFamily: 'var(--font-serif)' }}
                  className="text-5xl text-[var(--charcoal)] mb-6 leading-tight"
                >
                  The Law of <span className="italic text-[var(--crazy-pink)]">Four</span>
                </h2>
                <div className="w-20 h-[1px] bg-[var(--bespoke-gold)] mb-8" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, delay: 0.2 }}
            className="col-span-7 space-y-6"
            style={{ fontFamily: 'var(--font-sans)' }}
          >
            <p className="text-lg leading-relaxed text-[var(--charcoal)] opacity-80">
              Excellence cannot be rushed. Each day, our Master Chef creates exactly four commissioned
              masterpieces—no more, no less. This is not scarcity for spectacle. It is the natural
              limit of perfection.
            </p>

            <p className="text-lg leading-relaxed text-[var(--charcoal)] opacity-80">
              A single Tres Leches requires 48 hours of cold soaking. Ice cream is hand-churned in
              small batches. Pastries are laminated by hand, fold by fold. These processes cannot be
              hurried, delegated, or mechanized without compromise.
            </p>

            <p className="text-lg leading-relaxed text-[var(--charcoal)] opacity-80">
              When you commission from Crazy Crumbs, you are not purchasing a product. You are
              reserving one of four daily slots in a practice that values craft over convenience.
            </p>

            <div className="pt-6 grid grid-cols-3 gap-8">
              {[
                { label: 'Zero Preservatives', icon: '✓' },
                { label: 'Made to Order', icon: '✓' },
                { label: 'Fixed Pricing', icon: '✓' }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.4 + i * 0.1 }}
                  className="text-center"
                >
                  <div className="text-2xl text-[var(--bespoke-gold)] mb-2">{item.icon}</div>
                  <div className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-60">
                    {item.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
