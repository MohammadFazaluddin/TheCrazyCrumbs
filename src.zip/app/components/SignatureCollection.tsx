import { motion } from 'motion/react';
import { useInView } from './hooks/useInView';
import { ImageWithFallback } from './figma/ImageWithFallback';

const collections = [
  {
    name: 'World-Class Tres Leches',
    description: 'Three milks. Forty-eight hours. A texture that defies gravity.',
    image: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&h=600&fit=crop',
    price: 'From $180'
  },
  {
    name: 'Artisanal Ice Cream',
    description: 'Single-origin vanilla. Hand-churned. Zero stabilizers.',
    image: 'https://images.unsplash.com/photo-1633933358116-a27b902fad35?w=800&h=600&fit=crop',
    price: 'From $85'
  },
  {
    name: 'Heritage Pastries',
    description: 'French technique meets California ingredients. Laminated by hand.',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&h=600&fit=crop',
    price: 'From $120'
  }
];

function CollectionCard({ item, index }: { item: typeof collections[0]; index: number }) {
  const [ref, isInView] = useInView({ threshold: 0.3, triggerOnce: true });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay: index * 0.2 }}
      className="group cursor-pointer"
    >
      <div className="relative aspect-[4/3] overflow-hidden mb-6">
        <ImageWithFallback
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      <div className="space-y-3">
        <h3
          style={{ fontFamily: 'var(--font-serif)' }}
          className="text-2xl text-[var(--charcoal)] group-hover:text-[var(--crazy-pink)] transition-colors duration-300"
        >
          {item.name}
        </h3>

        <p
          style={{ fontFamily: 'var(--font-sans)' }}
          className="text-sm leading-relaxed text-[var(--charcoal)] opacity-70"
        >
          {item.description}
        </p>

        <div className="flex items-center justify-between pt-2">
          <span
            style={{ fontFamily: 'var(--font-sans)' }}
            className="text-xs tracking-widest uppercase text-[var(--bespoke-gold)]"
          >
            {item.price}
          </span>
          <span
            style={{ fontFamily: 'var(--font-sans)' }}
            className="text-xs tracking-widest uppercase text-[var(--charcoal)] opacity-40 group-hover:opacity-100 transition-opacity"
          >
            View Details →
          </span>
        </div>
      </div>
    </motion.div>
  );
}

export function SignatureCollection() {
  const [ref, isInView] = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section id="collection" className="py-32 px-8 bg-white">
      <div className="max-w-[1600px] mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <div className="text-xs tracking-[0.3em] uppercase text-[var(--charcoal)] opacity-60 mb-4">
            The Signature Collection
          </div>
          <h2
            style={{ fontFamily: 'var(--font-serif)' }}
            className="text-5xl text-[var(--charcoal)] mb-6"
          >
            Limited to <span className="italic text-[var(--crazy-pink)]">Four</span> Daily
          </h2>
          <div className="w-32 h-[1px] bg-[var(--bespoke-gold)] mx-auto" />
        </motion.div>

        <div className="grid grid-cols-3 gap-16">
          {collections.map((item, index) => (
            <CollectionCard key={index} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
